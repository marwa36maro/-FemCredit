# 🌸 FemCredit — Plateforme Décentralisée de Microcrédit

[![React](https://img.shields.io/badge/React-19-61DAFB?logo=react&logoColor=black)](https://react.dev/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.8-3178C6?logo=typescript&logoColor=white)](https://www.typescriptlang.org/)
[![Vite](https://img.shields.io/badge/Vite-6-646CFF?logo=vite&logoColor=white)](https://vitejs.dev/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-v4-38B2AC?logo=tailwind-css&logoColor=white)](https://tailwindcss.com/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

> **FemCredit** est une plateforme inclusive et décentralisée de microcrédit et de microfinance solidaire. Elle connecte directement des investisseurs éthiques et des femmes porteuses de projets à travers un système transparent de prêts, de remboursements échelonnés et de gestion automatisée des pénalités.

---

## 📌 À propos du projet

L'accès au crédit traditionnel reste un obstacle majeur pour des millions d'entrepreneures dans le monde. **FemCredit** démocratise le financement participatif peer-to-peer (P2P) et décentralisé en alliant simplicité d'utilisation, sécurité et impact social concret.

### 🎯 Objectifs
- **Inclusion financière** : Faciliter le financement des micro-entreprises et initiatives féminines.
- **Transparence et confiance** : Automatisation des conditions de prêt, des échéances et des calculs d'intérêts sans intermédiaires bancaires coûteux.
- **Remboursement intelligent** : Calendrier prédictif, relances bienveillantes et mécanisme de pénalités adaptatives pour sécuriser le capital des investisseurs tout en accompagnant les emprunteuses.

---

## ✨ Fonctionnalités Principales

### 👩‍💼 Pour les Emprunteuses
- **Création de dossier de micro-prêt** : Montant souhaité, durée, secteur d'activité et plan d'utilisation des fonds.
- **Échéancier clair et transparent** : Suivi mensuel des remboursements, intérêts précalculés et dates limites.
- **Système de score de confiance (Credit Score)** : Chaque remboursement à l'heure améliore la réputation et débloque des montants d'emprunt supérieurs avec des taux réduits.
- **Gestion des imprévus** : Notifications proactives avant échéance et politique de pénalités graduelles transparentes.

### 💼 Pour les Investisseurs / Prêteurs
- **Catalogue de projets vérifiés** : Découverte des micro-entreprises avec critères d'impact, montant requis, taux de rendement annuel (APY) et niveau de risque.
- **Investissement flexible** : Participation par fractions de prêt (crowdlending) ou financement total.
- **Tableau de bord de rentabilité** : Suivi en direct des intérêts perçus, du retour sur investissement (ROI) et des remboursements reçus.
- **Protection du capital** : Règles de recouvrement automatiques et fonds de réserve solidaire.

### ⚙️ Moteur Financier & Règles Métier
- **Calcul automatique des mensualités** : Formule amortissable standard ou linéaire.
- **Gestion intelligente des retards & pénalités** : Période de grâce (grace period), pénalités journalières plafonnées et préservation de l'équité.
- **Statistiques & Métriques en direct** : Visualisation graphique des flux, taux de recouvrement et impact social.

---

## 🛠️ Stack Technique

- **Frontend** : [React 19](https://react.dev/), [TypeScript](https://www.typescriptlang.org/)
- **Build Tool** : [Vite](https://vitejs.dev/)
- **Styles & Design** : [Tailwind CSS v4](https://tailwindcss.com/)
- **Composants d'icônes** : [Lucide React](https://lucide.dev/)
- **Visualisations & Graphiques** : [Recharts](https://recharts.org/)
- **Animations** : [Motion](https://motion.dev/)

---

## 🚀 Démarrage Rapide

### Prérequis
- [Node.js](https://nodejs.org/) (version 18 ou supérieure)
- [npm](https://www.npmjs.com/) ou [bun](https://bun.sh/)

### Installation

1. **Cloner le dépôt :**
   ```bash
   git clone https://github.com/votre-nom-utilisateur/femcredit.git
   cd femcredit
   ```

2. **Installer les dépendances :**
   ```bash
   npm install
   ```

3. **Lancer le serveur de développement :**
   ```bash
   npm run dev
   ```
   L'application sera accessible sur `http://localhost:3000`.

4. **Compiler pour la production :**
   ```bash
   npm run build
   ```

---

## 📂 Architecture du Projet

```text
femcredit/
├── public/              # Fichiers statiques et assets
├── src/
│   ├── components/      # Composants UI réutilisables (Cartes, Modales, Tables)
│   ├── features/        # Modules métier (Prêts, Investissements, Dashboard)
│   ├── hooks/           # Hooks personnalisés (calculs financiers, wallet)
│   ├── types/           # Définitions TypeScript (Loan, User, Repayment)
│   ├── utils/           # Fonctions utilitaires & calculs d'intérêts/pénalités
│   ├── App.tsx          # Composant racine
│   ├── main.tsx         # Point d'entrée de l'application
│   └── index.css        # Styles globaux Tailwind
├── package.json         # Dépendances et scripts
├── tsconfig.json        # Configuration TypeScript
├── vite.config.ts       # Configuration Vite
└── README.md            # Documentation du projet
```

---

## 🗺️ Feuille de Route (Roadmap)

- [x] Architecture du projet et design système inclusif
- [x] Simulateur de prêt et tableau d'amortissement dynamique
- [x] Gestion des rôles Investisseur / Emprunteuse
- [ ] Intégration Wallet Web3 (MetaMask, WalletConnect) & Smart Contracts de séquestre (Escrow)
- [ ] Déploiement d'un micro-fonds de garantie communautaire
- [ ] Application mobile PWA pour zones à connectivité limitée

---

## 🤝 Contribution

Les contributions sont les bienvenues ! Pour contribuer :
1. Forkez le projet
2. Créez votre branche de fonctionnalité (`git checkout -b feature/amelioration-tableau-bord`)
3. Commitez vos modifications (`git commit -m "feat: ajout du filtre par secteur d'activité"`)
4. Pushez vers la branche (`git push origin feature/amelioration-tableau-bord`)
5. Ouvrez une **Pull Request**

---

## 📄 Licence

Ce projet est sous licence MIT — consultez le fichier [LICENSE](LICENSE) pour plus de détails.

---

## 📬 Contact & Support

Pour toute question, suggestion ou partenariat :
- **Auteure / Équipe** : [FemCredit Team](https://github.com/votre-nom-utilisateur)
- **Email** : support@femcredit.org
